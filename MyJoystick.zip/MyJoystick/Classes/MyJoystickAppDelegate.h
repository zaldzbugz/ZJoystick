//
//  MyJoystickAppDelegate.h
//  MyJoystick
//
//  Created by ZaldzBugz on 4/1/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyJoystickAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
