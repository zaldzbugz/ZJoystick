//
//  HelloWorldLayer.m
//  MyJoystick
//
//  Created by ZaldzBugz on 4/1/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

// Import the interfaces
#import "HelloWorldScene.h"

// HelloWorld implementation
@implementation HelloWorld

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorld *layer = [HelloWorld node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	if( (self=[super init] )) {
		CGSize size = [CCDirector sharedDirector].winSize;
		
        //lime background image
		CCSprite *bg  = [CCSprite spriteWithFile:@"background.png"];
        bg.position   = ccp(size.width/2, size.height/2);   
		[self addChild:bg];
		
        //------------Joystick 1 with local controlled sprite and without setting up DELEGATE------------
        
		//Controlled sprite object 
		CCSprite *controlledSprite  = [CCSprite spriteWithFile:@"Icon.png"];
        controlledSprite.position   = ccp(size.width/2 - controlledSprite.contentSize.width , size.height/2);   
		[self addChild:controlledSprite];
        
        //Joystick1
        ZJoystick *_joystick1        = [ZJoystick joystickNormalSpriteFile:@"JoystickContainer_norm.png" 
														selectedSpriteFile:@"JoystickContainer_trans.png" 
													  controllerSpriteFile:@"Joystick_norm.png"];
        _joystick1.position          = ccp(_joystick1.contentSize.width/2, _joystick1.contentSize.height/2);
		_joystick1.controlledObject  = controlledSprite;
        _joystick1.speedRatio        = 1.0f;
        _joystick1.joystickRadius    = 50.0f;   //added in v1.2
		[self addChild:_joystick1];
        
        
        //------------Joystick 2 controlling GLOBAL sprite, set DELEGATE and set TAG------------
        //Controlled object
        //Controlled object's position gets updated in protocol method of zJoystick
        globalSprite                = [CCSprite spriteWithFile:@"Icon.png"];
        globalSprite.position       = ccp(size.width/2 + globalSprite.contentSize.width, size.height/2);   
		[self addChild:globalSprite];
        
        //Joystick2
        ZJoystick *_joystick2		 = [ZJoystick joystickNormalSpriteFile:@"JoystickContainer_norm.png" 
											 selectedSpriteFile:@"JoystickContainer_trans.png" 
										   controllerSpriteFile:@"Joystick_norm.png"];
        _joystick2.position          = ccp(size.width - _joystick2.contentSize.width/2, _joystick2.contentSize.height/2);
		_joystick2.delegate          = self;    //Joystick Delegate
        _joystick2.controlledObject  = globalSprite;
        _joystick2.speedRatio        = 2.0f;
        _joystick2.joystickRadius    = 50.0f;   //added in v1.2
        _joystick2.joystickTag       = 999;
		[self addChild:_joystick2];
	}
	return self;
}

#pragma mark -
#pragma mark Delegate - Jostick Methods
-(void)joystickControlBegan {
	CCLOG(@"Joystick Began Controlling");
	
}

-(void)joystickControlMoved {
	CCLOG(@"Joystick Move Controlling");
	
}

-(void)joystickControlEnded {
	CCLOG(@"Joystick End Controlling");
	
}

-(void)joystickControlDidUpdate:(id)joystick toXSpeedRatio:(CGFloat)xSpeedRatio toYSpeedRatio:(CGFloat)ySpeedRatio{
    
    ZJoystick *zJoystick = (ZJoystick *)joystick;
    
    if (zJoystick.joystickTag == 999) {
        CGFloat xPos = globalSprite.position.x;
        CGFloat yPos = globalSprite.position.y;
        globalSprite.position = ccp(xPos + xSpeedRatio, yPos + ySpeedRatio);
    }
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
