//
//  zJoystickAppDelegate.h
//  zJoystick
//
//  Created by ZaldzBugz on 3/25/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface zJoystickAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end
