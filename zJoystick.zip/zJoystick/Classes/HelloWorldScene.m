//
//  HelloWorldLayer.m
//  zJoystick
//
//  Created by ZaldzBugz on 3/25/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

// Import the interfaces
#import "HelloWorldScene.h"


// HelloWorld implementation
@implementation HelloWorld

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorld *layer = [HelloWorld node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init] )) {
		
        CGSize winSize = [CCDirector sharedDirector].winSize;
        
		//Controlled Object
		CCSprite *controlledSprite  = [CCSprite spriteWithFile:@"Icon.png"];
        controlledSprite.position   = ccp(winSize.width/2, winSize.height/2);   
		[self addChild:controlledSprite];
        
        //Joystick
        Joystick *_joystick         = [Joystick joystickNormalSpriteFile:@"JoystickContainer_norm.png" 
                                                      selectedSpriteFile:@"JoystickContainer_trans.png" 
                                                    controllerSpriteFile:@"Joystick_norm.png"];
        _joystick.position          = ccp(_joystick.contentSize.width/2, _joystick.contentSize.height/2);
		_joystick.delegate          = self;			//Joystick Delegate
		_joystick.controlledObject  = controlledSprite;
        _joystick.speedRatio        = 2.0f;
		[self addChild:_joystick];
        
	}
	return self;
}

#pragma mark -
#pragma mark Delegate - Jostick Methods
-(void)joystickControlBegan {
	CCLOG(@"Joystick Began Controlling");

}

-(void)joystickControlMoved {
	CCLOG(@"Joystick Move Controlling");

}

-(void)joystickControlEnded {
	CCLOG(@"Joystick End Controlling");

}
#pragma mark -
// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end
